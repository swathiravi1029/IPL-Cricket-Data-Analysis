
import pandas as pd
matches=pd.read_csv(r"C:\Users\Swathi Ravi\Downloads\matches.csv")
deliveries=pd.read_csv(r"C:\Users\Swathi Ravi\Downloads\deliveries-1.csv")
print(matches.shape)
print(deliveries.shape)
print(matches.columns.tolist())
print(deliveries.columns.tolist())
print(matches.info())
print(deliveries.info())
print("Missing values in matches:")
print(matches.isnull().sum())
print("Missing values in deliveries:")
print(deliveries.isnull().sum())
print("Duplicate matches:",matches.duplicated().sum())
print("Duplicate deliveries:",deliveries.duplicated().sum())
##Number of matches in each season
season_matches=matches.groupby("season")["id"].count()
print(season_matches)
##Number of wins by each team
team_wins=matches["winner"].value_counts()
print(team_wins)
##top 10
print(team_wins.head(10))
##matches played by each team
team1_count=matches["team1"].value_counts()
team2_count=matches["team2"].value_counts()
matches_played=team1_count.add(team2_count,fill_value=0)
print(matches_played.sort_values(ascending=False))
##calculate win percentage
team_performance = pd.DataFrame({
    "Matches Played": matches_played,
    "Wins": team_wins
}).fillna(0)

team_performance["Losses"] = (
    team_performance["Matches Played"] -
    team_performance["Wins"]
)

team_performance["Win Percentage"] = (
    team_performance["Wins"] /
    team_performance["Matches Played"] * 100
)

team_performance = team_performance.sort_values(
    "Win Percentage",
    ascending=False
)

print(team_performance)

##toss analysis
toss_match = matches["toss_winner"] == matches["winner"]

print("Toss winner also won:",
      toss_match.mean() * 100, "%")

##Toss decisions:

matches["toss_decision"].value_counts()

##Toss Decision vs Match Result

pd.crosstab(
    matches["toss_decision"],
    toss_match,
    normalize="index"
) * 100


import matplotlib.pyplot as plt
import seaborn as sns

##Venue Analysis

venue_analysis = matches["venue"].value_counts()

venue_analysis.head(10)

venue_analysis.head(10).sort_values().plot(
    kind="barh",
    figsize=(10,6)
)

plt.title("Top 10 IPL Venues")
plt.xlabel("Number of Matches")
plt.ylabel("Venue")
plt.show()


## Season-wise Winning Trends

season_wins = pd.crosstab(
    matches["season"],
    matches["winner"]
)

season_wins

season_wins.plot(figsize=(14,7))

plt.title("Team Winning Trends Across IPL Seasons")
plt.xlabel("Season")
plt.ylabel("Number of Wins")
plt.show()

## Player of the Match

matches["player_of_match"].value_counts().head(10)



team1_matches = matches["team1"].value_counts()
team2_matches = matches["team2"].value_counts()

matches_played = team1_matches.add(team2_matches, fill_value=0)

team_wins = matches["winner"].value_counts()

team_performance = pd.DataFrame({
    "Matches Played": matches_played,
    "Wins": team_wins
}).fillna(0)

team_performance["Losses"] = (
    team_performance["Matches Played"] -
    team_performance["Wins"]
)

team_performance["Win Percentage"] = (
    team_performance["Wins"] /
    team_performance["Matches Played"]
) * 100

team_performance.sort_values(
    "Win Percentage",
    ascending=False
)

##Chart

plt.figure(figsize=(12,6))

team_performance.sort_values(
    "Win Percentage"
)["Win Percentage"].plot(kind="barh")

plt.title("Team Win Percentage")
plt.xlabel("Win Percentage")
plt.ylabel("Team")

plt.show()



##Top 10 Players by Average Runs


player_match_runs = deliveries.groupby(
    ["match_id", "batsman"]
)["batsman_runs"].sum().reset_index()

player_avg_runs = player_match_runs.groupby(
    "batsman"
)["batsman_runs"].mean().sort_values(
    ascending=False
)

player_avg_runs.head(10)

##Chart:

plt.figure(figsize=(10,6))

player_avg_runs.head(10).sort_values().plot(
    kind="barh"
)

plt.title("Top 10 Players by Average Runs per Match")
plt.xlabel("Average Runs")
plt.ylabel("Player")

plt.show()


 ##Top Wicket Takers — Improve Your Existing Analysis



top_wicket_takers = deliveries[
    deliveries["is_wicket"] == 1
].groupby("bowler")["is_wicket"].sum().sort_values(
    ascending=False
)

##Add:

top_wicket_takers.head(10)

##Chart:

plt.figure(figsize=(10,6))

top_wicket_takers.head(10).sort_values().plot(
    kind="barh"
)

plt.title("Top 10 IPL Wicket Takers")
plt.xlabel("Wickets")
plt.ylabel("Bowler")

plt.show()

##For a more accurate bowling analysis, exclude wickets such as run out if your dataset has a dismissal_kind column.

bowler_wickets = deliveries[
    (deliveries["is_wicket"] == 1) &
    (~deliveries["dismissal_kind"].isin(["run out", "retired hurt", "obstructing the field"]))
]

top_bowlers = bowler_wickets.groupby(
    "bowler"
)["is_wicket"].sum().sort_values(
    ascending=False
)

top_bowlers.head(10)


## Team vs Team Analysis


matches["team_pair"] = matches.apply(
    lambda x: " vs ".join(
        sorted([x["team1"], x["team2"]])
    ),
    axis=1
)

matches["team_pair"].value_counts().head(10)


## Head-to-Head Team Analysis

team_a = "Mumbai Indians"
team_b = "Chennai Super Kings"

head_to_head = matches[
    (
        ((matches["team1"] == team_a) & (matches["team2"] == team_b)) |
        ((matches["team1"] == team_b) & (matches["team2"] == team_a))
    )
]

head_to_head["winner"].value_counts()

## Toss Winner vs Match Winner

toss_match = matches["toss_winner"] == matches["winner"]

toss_summary = pd.DataFrame({
    "Toss Result": ["Toss Winner Won Match", "Toss Winner Lost Match"],
    "Matches": [
        toss_match.sum(),
        (~toss_match).sum()
    ]
})

toss_summary

##Chart:

plt.figure(figsize=(8,5))

plt.bar(
    toss_summary["Toss Result"],
    toss_summary["Matches"]
)

plt.title("Impact of Toss on Match Result")
plt.ylabel("Number of Matches")

plt.xticks(rotation=15)

plt.show()

##Then calculate:

toss_win_percentage = toss_match.mean() * 100

print(
    f"Toss winner also won the match in "
    f"{toss_win_percentage:.2f}% of matches."
)

## Batting First vs Chasing


first_innings = deliveries[
    deliveries["inning"] == 1
]

first_innings_team = first_innings.groupby(
    "match_id"
)["batting_team"].first().reset_index()

first_innings_team.rename(
    columns={"batting_team": "first_batting_team"},
    inplace=True
)

match_analysis = matches.merge(
    first_innings_team,
    left_on="id",
    right_on="match_id",
    how="left"
)

##Now:

match_analysis["batting_first_won"] = (
    match_analysis["winner"] ==
    match_analysis["first_batting_team"]
)

##Calculate:

match_analysis["batting_first_won"].value_counts()

##Percentage:

match_analysis["batting_first_won"].mean() * 100

##Chart

batting_first_result = match_analysis[
    "batting_first_won"
].value_counts()

batting_first_result.index = [
    "Chasing Team Won",
    "Batting First Won"
]

batting_first_result.plot(
    kind="bar",
    figsize=(8,5)
)

plt.title("Batting First vs Chasing")
plt.ylabel("Number of Matches")
plt.xticks(rotation=0)

plt.show()



team_scores = deliveries.groupby(
    ["match_id", "inning", "batting_team"]
)["total_runs"].sum().reset_index()

team_scores.sort_values(
    "total_runs",
    ascending=False
).head(10)

##Chart:

top_scores = team_scores.sort_values(
    "total_runs",
    ascending=False
).head(10)

plt.figure(figsize=(10,6))

plt.barh(
    top_scores["batting_team"],
    top_scores["total_runs"]
)

plt.title("Top 10 Highest Team Innings Scores")
plt.xlabel("Runs")
plt.ylabel("Team")

plt.show()


## Average Team Score

average_team_score = team_scores.groupby(
    "batting_team"
)["total_runs"].mean().sort_values(
    ascending=False
)

average_team_score.head(10)


## Highest Individual Score

individual_scores = deliveries.groupby(
    ["match_id", "batsman"]
)["batsman_runs"].sum().reset_index()

individual_scores.sort_values(
    "batsman_runs",
    ascending=False
).head(10)

##Chart:

top_individual_scores = individual_scores.sort_values(
    "batsman_runs",
    ascending=False
).head(10)

plt.figure(figsize=(10,6))

plt.barh(
    top_individual_scores["batsman"],
    top_individual_scores["batsman_runs"]
)

plt.title("Top Individual IPL Scores")
plt.xlabel("Runs")
plt.ylabel("Player")

plt.show()


## Most Sixes

sixes = deliveries[
    deliveries["batsman_runs"] == 6
].groupby("batsman").size().sort_values(
    ascending=False
)

sixes.head(10)

sixes.head(10).sort_values().plot(
    kind="barh",
    figsize=(10,6)
)

plt.title("Top 10 Players by Number of Sixes")
plt.xlabel("Sixes")
plt.ylabel("Player")

plt.show()


## Most Fours

fours = deliveries[
    deliveries["batsman_runs"] == 4
].groupby("batsman").size().sort_values(
    ascending=False
)

fours.head(10)

## Run Rate by Season


season_run_rate = deliveries.groupby(
    "match_id"
).agg(
    total_runs=("total_runs", "sum"),
    total_balls=("ball", "count")
).reset_index()

##Merge season:

season_run_rate = season_run_rate.merge(
    matches[["id", "season"]],
    left_on="match_id",
    right_on="id",
    how="left"
)


season_run_rate_summary = season_run_rate.groupby(
    "season"
).agg(
    total_runs=("total_runs", "sum"),
    total_balls=("total_balls", "sum")
)

season_run_rate_summary["Run Rate"] = (
    season_run_rate_summary["total_runs"] /
    season_run_rate_summary["total_balls"]
) * 6

season_run_rate_summary


plt.figure(figsize=(12,6))

season_run_rate_summary["Run Rate"].plot(
    marker="o"
)

plt.title("IPL Run Rate Across Seasons")
plt.xlabel("Season")
plt.ylabel("Runs per Over")
plt.grid(True)

plt.show()


## Player of the Match Analysis


pom = matches["player_of_match"].value_counts()


plt.figure(figsize=(10,6))

pom.head(10).sort_values().plot(
    kind="barh"
)

plt.title("Top 10 Player of the Match Award Winners")
plt.xlabel("Awards")
plt.ylabel("Player")

plt.show()

pom.head(10)

## Create a Final Summary Table


summary = pd.DataFrame({
    "Metric": [
        "Total Matches",
        "Total Seasons",
        "Total Teams",
        "Total Venues",
        "Total Players"
    ],
    "Value": [
        matches["id"].nunique(),
        matches["season"].nunique(),
        pd.concat([
            matches["team1"],
            matches["team2"]
        ]).nunique(),
        matches["venue"].nunique(),
        deliveries["batsman"].nunique()
    ]
})
